Genome used are from Ensembl version 75 (www.ensembl.org)
- Human: GRCh37
- Mouse: GRCm38
- Platypus: OANA5
- Chicken: Galgal4
- Lizard: AnoCar2.0
- Frog: JGI 4.2
- Zebrafish: Zv9
